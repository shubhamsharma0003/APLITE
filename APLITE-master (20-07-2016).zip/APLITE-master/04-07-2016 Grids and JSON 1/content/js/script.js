// Using AJAX to send a request
// function func() {
// 	var xhttp = new XMLHttpRequest();
// 	xhttp.onreadystatechange = function() {
// 		if (xhttp.readyState == 4 && xhttp.status == 200) {

// 			$(".content").html(xhttp.responseXML);
// 			alert("in");
// 		}
// 	};
// 	xhttp.open("GET", "xmlfile.xml", true);
// 	xhttp.send();
// } // Using AJAX to send a request